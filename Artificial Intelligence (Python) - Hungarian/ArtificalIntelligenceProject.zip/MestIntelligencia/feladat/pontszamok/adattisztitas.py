import pandas as pd

filePath = "C:/Users/Tamás/Desktop/Gazdinfó/Gazdinfó-harmadév/MasodikFelev/MestIntelligencia/feladat/pontszamok/Copy of 2023 - Copy.csv"
data = pd.read_csv(filePath, header = None)

dataTransformed = data.iloc[0:2].transpose()
dataTransformed.columns = ["Csapat", "Pontszám"]

dataTransformed = dataTransformed.drop(0)

dataTransformed.reset_index(drop = True, inplace = True)

dataTransformed["Pontszám"] = pd.to_numeric(dataTransformed["Pontszám"], errors = 'coerce')

outputPath = "C:/Users/Tamás/Desktop/Gazdinfó/Gazdinfó-harmadév/MasodikFelev/MestIntelligencia/feladat/pontszamok/Copy of 2023 - Copy.csv"
dataTransformed.to_csv(outputPath, index = False)